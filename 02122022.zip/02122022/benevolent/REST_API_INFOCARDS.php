<?php

// INFOCARDS GET ==========================================================================
	// GENERAL VARS ==================
		$resource_get="infocards1";
		$ip="192.168.1.67";
		$port="4000";
	// ===============================

	// DECRYPT VARS ================================
		$cipher ="AES-256-ECB";
		$key = 'KeyMustBe16ByteOR24ByteOR32ByT1!';
	// =============================================

	// URL WEBSERVICE =====================================================
		// URL web service prod http://192.168.1.67:4000/infocards5/user1
		$url = "http://".$ip.":".$port."/".$resource_get."/".$user;

		// URL web service test http://192.168.1.67:4000/test
		//$url = "http://".$ip.":".$port."/test";
	// ====================================================================

	// CONSUMIR Y DESENCRIPTAR WEB SERVICE ==========================================
		// INIT CONNEXION
		$client = curl_init($url);
		curl_setopt($client,CURLOPT_RETURNTRANSFER,true);
		$response = curl_exec($client);

		// DESENCRIPTAR JSON
		$chiperRaw = base64_decode($response);
		$originalPlaintext = openssl_decrypt($chiperRaw, $cipher, $key, OPENSSL_RAW_DATA);

		// ALMACENAR RESULTADO EN ARRAY
		$result = json_decode($originalPlaintext); 

		// CERRAR LA CONEXION
		curl_close($client);

	// ===============================================================
// FIN INFOCARDS GET =========================================================================

?>