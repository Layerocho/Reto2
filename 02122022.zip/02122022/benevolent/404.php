<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Benevolent
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">            
            <div class="error-holder">
				<div class="icon-holder">
                    <img src="<?php echo esc_url( get_template_directory_uri() . '/images/gandalf.png' ); ?>" alt="<?php esc_attr_e( 'Error 404', 'benevolent' ); ?>" />
                </div>
				<h1><?php esc_html_e( 'You Shall not pass', 'benevolent' ); ?></h2>
				<p><?php esc_html_e( 'Go back to the abyss from where you came, beast.', 'benevolent' ); ?></p>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Return to Homepage', 'benevolent' ); ?></a>
			</div>            
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();