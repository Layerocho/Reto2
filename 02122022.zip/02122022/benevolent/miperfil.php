<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent
 */
 $sidebar_layout = benevolent_sidebar_layout();

/*
Template Name: miperfil
*/

// RELOAD HEADER =================
    ob_start();
    get_header();
// FIN RELOAD HEADER =================

?>

<?php
// REDIRECCION A LOGIN SI NO ESTA LOGEADO =======================================================
    if ( is_user_logged_in() ) {
    } else{?>
        <div class="card-body-login">
        <div class="card-content-login"><br>
        <h3>No estas logeado</h3>
        <p><a href="https://layer8.local/?page_id=38">Ir ala pagina de login</a></p><br>
        </div>
        </div>
    <?php
    }
// FIN REDIRECCION A LOGIN SI NO ESTA LOGEADO =======================================================
?>


<div id="content-body-perfil">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', 'page' );
                
                // If comments are open or we have at least one comment, load up the comment template.
    			if ( comments_open() || get_comments_number() ) :
    				comments_template();
    			endif;

			endwhile; // End of the loop.

        // VARS API REST ===================
            $user="user1";
            //$user=$_POST['username'];
        // FIN VARS API REST ==================
        
        // LLAMADA API REST ============================================================================================
            if (isset($user) && $user!="") {
                include 'REST_API_INFOCARDS.php';
                // UPDATE API REST ===============================================================================
                    if(isset($_POST['buttonActive'])){
                        if($_POST['buttonActive']=="europe"){
                            $newactivecard="EUROPE";
                        } elseif($_POST['buttonActive']=="international"){
                            $newactivecard="INTERNATIONAL";
                        }
                        include 'REST_API_ENABLECARDS.php';
                        header("Refresh:0");
                    }
                // FIN UPDATE API REST ===========================================
                
                // DIV TARJETAS ==================================================================================?>      
                   <div id="formTarjetas"><center>                 
                        <?php // FORM =========================================================================?>
                            <!-- TEST FORM -->
                            <!-- <form action="https://layer8.local/".<?php echo $_SERVER['PHP_SELF']; ?> method="POST" > -->
                           
                            <!-- TEST2 FORM -->                           
                            <!--<form action="<?php echo $_SERVER['PHP_SELF'];?>?page_id=24" method="POST" >-->
                           
                            <!-- ORIGINAL FORM -->                           
                            <form action="https://layer8.local/?page_id=24" method="POST" >
                            
                                <table class="general_table">
                                    
                                    <tr>
                                        <td> 
                                        <?php // BOTON EURO CARD ==================================
                                                $cardType="EUROPE";
                                                if($result->current_card=="EUROPE"){
                                                    //<input type="radio" name="card" value="europe" checked>
                                                    ?>
                                                    <button class="button_disabled" 
                                                            name="buttonActive" 
                                                            type="submit" 
                                                            value="europe_active" disabled>TARJETA ACTIVA</button>
                                                    <?php
                                                } else {
                                                    //<input type="radio" name="card" value="europe">
                                                   ?>
                                                    <button class="button_enabled" 
                                                            name="buttonActive" 
                                                            type="submit" 
                                                            value="europe">ACTIVAR</button>
                                                    <?php
                                                }
                                            // FIN BOTON EURO CARD ====================================?>
                                        </td>
                                        <td>
                                            <?php // EURO CARD ========================================
                                                $tipo_tarjeta=$result->card_europe;
                                                include 'tarjeta_obj.php';
                                  
                                            // FIN EURO CARD ==========================================?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                        <?php // BOTON INTERNATIONAL CARD =========================
                                                $cardType="INTERNATIONAL";
                                                if($result->current_card=="INTERNATIONAL"){
                                                    //<input type="radio" name="card"  value="international" checked>
                                                    ?>
                                                    <button class="button_disabled" 
                                                            name="buttonActive" 
                                                            type="submit" 
                                                            value="international_active" disabled>TARJETA ACTIVA</button>
                                                    <?php
                                                } else {
                                                    //<input type="radio" name="card"  value="international">
                                                    ?>
                                                    <button class="button_enabled" 
                                                            name="buttonActive" 
                                                            type="submit" 
                                                            value="international">ACTIVAR</button>
                                                    <?php
                                                }
                                            // FIN BOTON INTERNATIONAL CARD ===========================?>
                                        </td>
                                        <td>
                                            <?php // INTERNATIONAL CARD ===============================
                                                $tipo_tarjeta=$result->card_international;
                                                include 'tarjeta_obj.php';
                                            // FIN INTERNATIONAL CARD =================================?>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        <?php // FIN FORM =====================================================================?>
                    </center></div>
                <?php // FIN DIV TARJETAS ========================================================================?>
            <?php }  
        // FIN API REST ================================================================================================ ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
    if( $sidebar_layout == 'right-sidebar' )
    get_sidebar(); ?>
    </div>
    <?php
    get_footer();
?>