<?php

// ENABLECARDS GET ===========================================================================
	// GENERAL VARS ==================
		
		$resource_enabled="enablecard1";
		//$ip="192.168.1.67";
		//$port="4000";
		
		include 'REST_API_INFOCARDS.php';

		// GET TIMESTAMP ===================
			//$whenactive_eur=getdate();
			//$whenactive_int=getdate();
		// FIN GET TIMESTAMP ===============

		// TEST VARS =======================
			//$newactivecard_euro="EUROPE";
			//$newactivecard_inter="INTERNATIONAL";
		// FIN TEST VARS ===================

	// ===============================

	// URL WEBSERVICE =====================================================
		// URL web service prod http://192.168.1.67:4000/infocards5/user1
		$url_enable = "http://".$ip.":".$port."/".$resource_enabled."/".$user."/".$newactivecard;

		// URL web service test http://192.168.1.67:4000/test
		//$url = "http://".$ip.":".$port."/test";
	// ====================================================================

	// CONVERT ARRAY TO JSON ============================================================
		$data = array("lastactive_eur" => $result->lastactive_eur,
						"lastactive_int" => $result->lastactive_int,
						"card_europe" => $result->card_europe,
						"card_international" => $result->card_international,
						"current_card" => $newactivecard);
		$data_json = json_encode($data);
	// ==================================================================================

	// INIT CONNECTION ===========
		$client = curl_init($url_enable);
	// ===========================

	// CURL SET OPERATIONS ===============================================
		curl_setopt($client, CURLOPT_URL, $url_enable);
		curl_setopt($client, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Content-Length:'.strlen($data_json)));

		// SET Method as a PUT
		curl_setopt($client,CURLOPT_CUSTOMREQUEST,'GET');

		// Pass user data in POST command
		curl_setopt($client, CURLOPT_POSTFIELDS, $data_json);
		curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

		// Execute curl and assign returned data
		$response  = curl_exec($client);

		// Close curl
		curl_close($client);
	// ===================================================================

	// See response if data is posted successfully or any error
	//print_r ($response);

// FIN ENABLECARDS GET =======================================================================

?>