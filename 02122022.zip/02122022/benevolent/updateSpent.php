<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent
 */
 $sidebar_layout = benevolent_sidebar_layout();

/*
Template Name: updateSpent
*/

// RELOAD HEADER =================
    //ob_start();
    get_header();
// FIN RELOAD HEADER =================


    require('clases/expensesClass.php');
    require('clases/expensesFunction.php');
    
    $current_user = wp_get_current_user();

?>

	 <div class='card'>
          <div class="card-body"><br>
               <div class="card-content">
    <?php

        $ID_spent=$_GET['Spent_ID'];
        $user=$_GET['ID_User'];

        if (isset($_POST['guardar'])){

            $Expenses_date = $_POST['fecha'];
            $Expenses_description = $_POST['descripcion'];
            $Expenses_import = $_POST['importe'];
            $Expenses_cointype = $_POST['divisa'];
            $Expenses_project = $_POST['proyecto'];
            $Expenses_country = $_POST['pais'];
            $Expenses_ticket_ref = $_POST['ticket'];
            $Wp_users_ID = $_POST['wp_user_spent'];
            

            if (strlen($Expenses_date)> 0 && strlen($Expenses_import) > 0 && strlen($Expenses_cointype) > 0 && strlen($Expenses_project) > 0 && strlen($Expenses_country) > 0 && strlen($Wp_users_ID) > 0){

                $updated_spent= new Spent();
                
                $updated_spent->setExpenses_date($Expenses_date);
                $updated_spent->setExpenses_description($Expenses_description);
                $updated_spent->setExpenses_import($Expenses_import);
                $updated_spent->setExpenses_cointype($Expenses_cointype);
                $updated_spent->setExpenses_project($Expenses_project);
                $updated_spent->setExpenses_country($Expenses_country);
                $updated_spent->setExpenses_ticket_ref($Expenses_ticket_ref);
                $updated_spent->setWp_users_ID($Wp_users_ID);
                $updated_spent->setExpenses_id($ID_spent);

                if (ExpensesDB::updateSpent($updated_spent)>0){?>
					
                    <p>El gasto se ha modificado correctamente</p><br>
                    
                    
<?php           } else { ?>
            
                    <p>El gasto no se ha modificado correctamente</p><br>

                    
<?php           }   ?>
                
                <table class="fondoTabla" cellspacing='5' cellpadding='5' border='1'>
                    <tr>
                        <th>ID Usuario</th>
                        <td><?php   echo $Wp_users_ID  ?></td>
                    </tr>
                    <tr>
                        <th>Descripción</th>
                        <td><?php   echo $Expenses_description  ?></td>
                    </tr>
                    <tr>
                        <th>Importe</th>
                        <td><?php   echo $Expenses_import  ?></td>
                    </tr>
                    <tr>
                        <th>Divisa</th>
                        <td><?php   echo $Expenses_cointype  ?></td>
                    </tr>
                    <tr>
                        <th>Fecha</th>
                        <td><?php   echo $Expenses_date  ?></td>
                    </tr>
                    <tr>
                        <th>Proyecto</th>
                        <td><?php   echo $Expenses_project  ?></td>
                    </tr>
                    <tr>
                        <th>Pais</th>
                        <td><?php   echo $Expenses_country  ?></td>
                    </tr>
                    <tr>
                        <th>Ticket</th>
                        <td><?php   echo $Expenses_ticket_ref  ?></td>
                    </tr>
                </table>
                <a href='https://layer8.local/?page_id=164'> ATRAS </a><br><br>

<?php       }else{  ?>

                
                    <h1>Rellena todos los campos</h1>
                    <form action="" method="post" enctype="multipart/form-data">
                        <p>
                            <label for="wp_user_spent">Id usuario</label>
                            <input type="text" id="wp_user_spent" name="wp_user_spent" size="50" maxlength="200" value="<?php echo $Wp_users_ID ?>" readonly >
                        </p>
                        <p>
                            <label for="descripcion">Descripción</label>
                            <textarea id="descripcion" name="descripcion"><?php echo $Expenses_description?></textarea>
                        </p>
                        <p>
                            <label for="importe">Importe</label>
                            <input type="text" id="importe" name="importe" value="<?php echo $Expenses_import ?>">
                        </p>
                        <p>
                            <label for="divisa">Divisa</label>
                            <input type="text" id="divisa" name="divisa" size="50" maxlength="200" value="<?php echo $Expenses_cointype ?>">
                        </p>
                        <p>
                            <label for="fecha">Fecha</label>
                            <input type="date" id="fecha" name="fecha" value="<?php echo $Expenses_date ?>">
                        </p>
                        <p>
                            <label for="proyecto">Proyecto</label>
                            <input type="text" id="proyecto" name="proyecto" size="50" maxlength="200" value="<?php echo $Expenses_project ?>">
                        </p>
                        <p>
                            <label for="pais">Pais</label>
                            <input type="text" id="pais" name="pais" size="50" maxlength="200" value="<?php echo $Expenses_country ?>">
                        </p>
                        <p>
                            <label for="ticket">Ticket</label>
                            <input type="text" id="ticket" name="ticket" size="50" maxlength="200" value="<?php echo $Expenses_ticket_ref ?>">
                        </p>
                        <p>
                            <input type="submit" id="gorde" name="guardar" value="GUARDAR">
                        </p><br>
                    </form>
           


<?php       }


        }else{  ?>
            
           
                <h1>UPDATE GASTO</h1>
                
                <?php 
                    $spent = ExpensesDB::selectSpent($ID_spent);?>
                    <form action="" method="post" enctype="multipart/form-data">
                        <p>
                            <label for="wp_user_spent">Id usuario</label>
                            <input type="text" id="wp_user_spent" name="wp_user_spent" size="50" maxlength="200" value="<?php echo $spent->getWp_users_ID() ?>" readonly >
                        </p>
                        <p>
                            <label for="descripcion">Descripción</label>
                            <textarea id="descripcion" name="descripcion"><?php echo $spent->getExpenses_description() ?></textarea>
                        </p>
                        <p>
                            <label for="importe">Importe</label>
                            <input type="text" id="importe" name="importe" value="<?php echo $spent->getExpenses_import() ?>">
                        </p>
                        <p>
                            <label for="divisa">Divisa</label>
                            <input type="text" id="divisa" name="divisa" size="50" maxlength="200" value="<?php echo $spent->getExpenses_cointype() ?>">
                        </p>
                        <p>
                            <label for="fecha">Fecha</label>
                            <input type="date" id="fecha" name="fecha" value="<?php echo $spent->getExpenses_date() ?>">
                        </p>
                        <p>
                            <label for="proyecto">Proyecto</label>
                            <input type="text" id="proyecto" name="proyecto" size="50" maxlength="200" value="<?php echo $spent->getExpenses_project() ?>">
                        </p>
                        <p>
                            <label for="pais">Pais</label>
                            <input type="text" id="pais" name="pais" size="50" maxlength="200" value="<?php echo $spent->getExpenses_country() ?>">
                        </p>
                        <p>
                            <label for="ticket">Ticket</label>
                            <input type="text" id="ticket" name="ticket" size="50" maxlength="200" value="<?php echo $spent->getExpenses_ticket_ref() ?>">
                        </p>
                        <p>
                            <input id="gorde" type="submit" name="guardar" value="GUARDAR">
                        </p>
                    </form><br>
                
              

<?php   } ?>
	
     				</div>
                </div>
            </div>
    
<?php
	

    if( $sidebar_layout == 'right-sidebar' )
    get_sidebar();
    get_footer();
?>