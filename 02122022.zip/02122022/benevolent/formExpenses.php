<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent
 */
 $sidebar_layout = benevolent_sidebar_layout();

/*
Template Name: formExpenses
*/

// RELOAD HEADER =================
    //ob_start();
    get_header();
// FIN RELOAD HEADER =================


    require('clases/expensesClass.php');
    require('clases/expensesFunction.php');
    
    $current_user = wp_get_current_user();

?>

<?php
// REDIRECCION A LOGIN SI NO ESTA LOGEADO =======================================================
    if ( is_user_logged_in() ) {
    } else{?>
        <div class="card-body-login">
        <div class="card-content-login"><br>
        <h3>No estas logeado</h3>
        <p><a href="https://layer8.local/?page_id=38">Ir ala pagina de login</a></p><br>
        </div>
        </div>
    <?php
    }
// FIN REDIRECCION A LOGIN SI NO ESTA LOGEADO =======================================================
?>

	<div id="vault">
                
         <div class='card-body'>
                   
             <div class='card-content'>
	
        <?php
        
            

            if (isset($_POST['guardar'])){

                $Expenses_date = $_POST['fecha'];
                $Expenses_description = $_POST['descripcion'];
                $Expenses_import = $_POST['importe'];
                $Expenses_cointype = $_POST['divisa'];
                $Expenses_project = $_POST['proyecto'];
                $Expenses_country = $_POST['pais'];
                $Expenses_ticket_ref = $_POST['ticket'];
                $Wp_users_ID = $_POST['ID_user'];
                
               
            

                if (strlen($Expenses_date)> 0 && strlen($Expenses_import) > 0 && strlen($Expenses_cointype) > 0 && strlen($Expenses_project) > 0 && strlen($Expenses_country) > 0 && strlen($Wp_users_ID) > 0){
                
                    $spent = new Spent();

                    $spent->setExpenses_date($Expenses_date);
                    $spent->setExpenses_description($Expenses_description);
                    $spent->setExpenses_import($Expenses_import);
                    $spent->setExpenses_cointype($Expenses_cointype);
                    $spent->setExpenses_project($Expenses_project);
                    $spent->setExpenses_country($Expenses_country);
                    $spent->setExpenses_ticket_ref($Expenses_ticket_ref);
                    $spent->setWp_users_ID($Wp_users_ID);
                            
                        if (ExpensesDB::insertSpent($spent)>0){?>
                                
                            <br><p>El gasto se ha guardado</p>
                                    
                <?php   } else { ?>
                    
                            <br><p>El gasto no se ha guardado</p>
                                
                <?php   } ?>
									
                                    <table class="fondoTabla" cellspacing="5" cellpadding="5" border="1">
                                        <tr>
                                            <th allign="right">Fecha</th>
                                            <td><?php  echo $Expenses_date?></td>
                                        </tr>
                                        <tr>
                                            <th allign="right">Descripción</th>
                                            <td><?php  echo $Expenses_description?></td>
                                        </tr>
                                        <tr>
                                            <th allign="right">Importe</th>
                                            <td><?php echo $Expenses_import ?></td>
                                        </tr>
                                        <tr>
                                            <th allign="right">Divisa</th>
                                            <td><?php  echo $Expenses_cointype?></td>
                                        </tr>
                                        <tr>
                                            <th allign="right">Proyecto</th>
                                            <td><?php  echo $Expenses_project?></td>
                                        </tr>
                                        <tr>
                                            <th allign="right">Pais</th>
                                            <td><?php  echo $Expenses_country?></td>
                                        </tr>
                                        <tr>
                                            <th allign="right">Ticket</th>
                                            <td><?php  echo $Expenses_ticket_ref?></td>
                                        </tr>
                                        <tr>
                                            <th allign="right">ID usuario</th>
                                            <td><?php  echo $Wp_users_ID ?></td>
                                        </tr>
                                    </table>
                                    <a href='https://layer8.local/?page_id=24'> SALIR </a><br>
                                    
                            
                    
        <?php   }else{ ?> 
        
                                <div style="margin:50px;"><br>
                                    <h1>Rellena todos los campos</h1>
                                    <form action="" method="post" enctype="multipart/form-data"> 
                                        <p>
                                            <label for="fecha">Fecha</label>
                                            <input type="date" id="fecha" name="fecha" size="50" maxlength="200" value="<?php echo $Expenses_date ?>">
                                        </p>
                                        <p>
                                            <label for="descripcion">Descripción</label>
                                            <textarea id="descripcion" name="descripcion"><?php echo $Expenses_description ?></textarea>
                                        </p>
                                        <p>
                                            <label for="importe">Importe</label>
                                            <input type="text" id="importe" name="importe" size="50" maxlength="200" value="<?php echo $Expenses_import ?>">
                                        </p>
                                        <p>
                                            <label for="divisa">Divisa</label>
                                            <input type="text" id="divisa" name="divisa" size="50" maxlength="200" value="<?php echo $Expenses_cointype ?>">
                                        </p>
                                        <p>
                                            <label for="proyecto">Proyecto</label>
                                            <input type="text" id="proyecto" name="proyecto" size="50" maxlength="200" value="<?php echo $Expenses_project ?>">
                                        </p>
                                        <p>
                                            <label for="pais">Pais</label>
                                            <input type="text" id="pais" name="pais" size="50" maxlength="200" value="<?php echo $Expenses_country ?>">
                                        </p>
                                        <p>
                                            <label for="ticket">Ticket</label>
                                            <input type="text" id="ticket" name="ticket" size="50" maxlength="200" value="<?php echo $Expenses_ticket_ref ?>">
                                        </p>
                                        <p>
                                            <label for="ID_user">ID usuario</label>
                                            <input type="text" id="ID_user" name="ID_user" size="50" maxlength="200" value="<?php echo $Wp_users_ID ?>">
                                        </p>
                                        <p>
                                            <input type="submit" id="gorde" name="guardar" value="Guardar">
                                        </p>
                                    </form><br>
                                </div>
                
        <?php   }
               
            }else{ ?>
            
                            <div class='card2' style="margin:50px;"><br>
                            <h1>Introduce los datos del gasto</h1>
                                <form action="https://layer8.local/?page_id=87" method="post" enctype="multipart/form-data">
                                    <p>
                                        <label for="fecha">Fecha de la transacción</label>
                                        <input type="date" id="fecha" name="fecha" size="50" maxlength="200" >
                                    </p>
                                    <p>
                                        <label for="descripcion">Descripción</label>
                                        <textarea id="descripcion" name="descripcion"></textarea>
                                    </p>
                                    <p>
                                        <label for="importe">Importe</label> 
                                        <input type="text" name="importe" id="importe" /><!-- CAMBIAR A TEXT SI NO FUNCIONA -->    
                                    </p>
                                    <p>
                                        <label for="divisa">Divisa</label>
                                        <input type="text" id="divisa" name="divisa" size="50" maxlength="200" >
                                    </p>
                                    <p>
                                        <label for="proyecto">Proyecto</label>
                                        <input type="text" id="proyecto" name="proyecto" size="50" maxlength="200" >
                                    </p>
                                    <p>
                                        <label for="pais">Pais</label>
                                        <input type="text" id="pais" name="pais" size="50" maxlength="200" >
                                    </p>
                                    <p>
                                        <label for="ticket">Ticket</label>
                                        <input type="text" id="ticket" name="ticket" size="50" maxlength="200" >
                                    </p>
                                    <p>
                                        <label for="ID_user">ID usuario</label>
                                        <input type="text" class="form-control" name="ID_user" id="ID_user" value="<?php echo "$current_user->ID" ?>" readonly >
                                    </p>
                                    
                                        <input id='gorde' type="submit" name="guardar" value="Guardar"><br><br>
                                    
                                </form>
                            </div>
                
        <?php 
            } ?> 
            </div>
         </div>
	</div>
<?php
    if( $sidebar_layout == 'right-sidebar' )
    get_sidebar();
    get_footer();
?>