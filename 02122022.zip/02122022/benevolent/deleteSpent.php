<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent
 */
 $sidebar_layout = benevolent_sidebar_layout();

/*
Template Name: deleteSpent
*/

// RELOAD HEADER =================
    //ob_start();
    get_header();
// FIN RELOAD HEADER =================


    require('clases/expensesClass.php');
    require('clases/expensesFunction.php');
    
    $current_user = wp_get_current_user();

?>
	 <div class="card-body"><br>
            
            <div class="card-content">

    <?php

        $ID_spent=$_GET['Spent_ID'];
        $user=$_GET['ID_User'];


        if(isset($_POST['si'])){
            //$Spent_ID=$spent->getExpenses_id();
            if(ExpensesDB::deleteSpent($ID_spent) > 0){ ?>
				
                <p>El gasto se elimino correctamente</p>
                <a href='https://layer8.local/?page_id=164'> ATRAS </a><br>
                
    <?php   }else{  ?>

                <p>El gasto no se elimino correctamente</p>
                <a href='https://layer8.local/?page_id=164'> ATRAS </a>

<?php       }   

        }elseif(isset($_POST['no'])){
        
        //De esta forma intentamos redirigir ala pagina 164 pero no nos ejecuta el codigo como nosotros queremos entonces hemos decidido ejecutarlo de otra forma mas cutre   
            /*$url="https://layer8.local/?page_id=164"; 
            wp_redirect( 'https://layer8.local/?page_id=164' );
            exit;*/
        // FIN CHAPUZA //////////////////////////////////////////////////////////////////////////
        
		?>
        <p>No quieres borrar el gasto</p>
        <a href='https://layer8.local/?page_id=164'> ATRAS </a>
        <?php
        
        }else{

            $spent=ExpensesDB::selectSpent($ID_spent); ?>
            
           
            <h1>DELETE GASTO</h1><br>
			<?php
            echo "<dl>\n";
            echo "<table class='fondoTabla' cellspacing='5' cellpadding='5' border='1'>";
            echo " <tr>";
            echo "  <th>ID Gasto</th>";
            echo "  <td>".$spent->getExpenses_id()."</td>";
            echo " </tr>";
            echo " <tr>";
            echo "  <th>Descripción</th>";
            echo "  <td>".$spent->getExpenses_description()."</td>";
            echo " </tr>";
            echo " <tr>";
            echo "  <th>Importe</th>";
            echo "  <td>".$spent->getExpenses_import()."</td>";
            echo " </tr>";
            echo " <tr>";
            echo "  <th>Divisa</th>";
            echo "  <td>".$spent->getExpenses_cointype()."</td>";
            echo " </tr>";
            echo " <tr>";
            echo "  <th>Fecha</th>";
            echo "  <td>".$spent->getExpenses_date()."</td>";
            echo " </tr>";
            echo " <tr>";
            echo "  <th>Proyecto</th>";
            echo "  <td>".$spent->getExpenses_project()."</td>";
            echo " </tr>";
            echo " <tr>";
            echo "  <th>Pais</th>";
            echo "  <td>".$spent->getExpenses_country()."</td>";
            echo " </tr>";
            echo " <tr>";
            echo "  <th>Ticket</th>";
            echo "  <td>".$spent->getExpenses_ticket_ref()."</td>";
            echo " </tr>";
            echo "</table>";

?>          <form action="" method="post">
                <p>
                	¿Estas seguro que deseas borrar este gasto?
                	<input id="Dboton" type="submit" name="si" value="SI">
                	<input id="Dboton" type="submit" name="no" value="NO">
             	</p>
            </form><br>
            

<?php   } ?>

		</div>
    </div>
<?php	

    if( $sidebar_layout == 'right-sidebar' )
    get_sidebar();
    get_footer();
?>