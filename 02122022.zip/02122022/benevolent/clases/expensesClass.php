<?php

class Spent
	{
		private $Expenses_id;
		private $Expenses_date;
		private $Expenses_description;
		private $Expenses_import;
		private $Expenses_cointype;
		private $Expenses_project;
		private $Expenses_country;
		private $Expenses_ticket_ref;

		//VARIABLE PARA LA FOREIGN KEY + GETERS + SETERS
		private $Wp_users_ID;
		

		
		public function __construct(){}


		
		public function setExpenses_id($Expenses_id){
			
			$this->Expenses_id = $Expenses_id;
		}
		public function getExpenses_id(){
			
			return $this->Expenses_id;
		}


		public function setExpenses_date($Expenses_date){
			
			$this->Expenses_date = $Expenses_date;
		}
		public function getExpenses_date(){
			
			return $this->Expenses_date;
		}


		public function setExpenses_description($Expenses_description){
			
			$this->Expenses_description = $Expenses_description;
		}
		public function getExpenses_description(){
			
			return $this->Expenses_description;
		}


		public function setExpenses_import($Expenses_import){
			
			$this->Expenses_import = $Expenses_import;
		}
		public function getExpenses_import(){
			
			return $this->Expenses_import;
		}


		public function setExpenses_cointype($Expenses_cointype){
			
			$this->Expenses_cointype = $Expenses_cointype;
		}
		public function getExpenses_cointype(){
			
			return $this->Expenses_cointype;
		}


		public function setExpenses_project($Expenses_project){
			
			$this->Expenses_project = $Expenses_project;
		}
		public function getExpenses_project(){
			
			return $this->Expenses_project;
		}


		public function setExpenses_country($Expenses_country){
			
			$this->Expenses_country = $Expenses_country;
		}
		public function getExpenses_country(){
			
			return $this->Expenses_country;
		}


		public function setExpenses_ticket_ref($Expenses_ticket_ref){
			
			$this->Expenses_ticket_ref = $Expenses_ticket_ref;
		}
		public function getExpenses_ticket_ref(){
			
			return $this->Expenses_ticket_ref;
		}

		//GETER Y SETER DE FOREIGN KEY

		public function setWp_users_ID($Wp_users_ID){
			
			$this->Wp_users_ID = $Wp_users_ID;
		}
		public function getWp_users_ID(){
			
			return $this->Wp_users_ID;
		}
		
		
	}

?>