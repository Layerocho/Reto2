<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Benevolent
 */
 $sidebar_layout = benevolent_sidebar_layout();

/*
Template Name: ExpensesUser
*/

// RELOAD HEADER =================
    //ob_start();
    get_header();
// FIN RELOAD HEADER =================



    require('clases/expensesClass.php');
    require('clases/expensesFunction.php');
    
    
	$current_user = wp_get_current_user();
    

?>

<?php
// REDIRECCION A LOGIN SI NO ESTA LOGEADO =======================================================
    if ( is_user_logged_in() ) {
    } else{?>
        <div class="card-body-login">
        <div class="card-content-login"><br>
        <h3>No estas logeado</h3>
        <p><a href="https://layer8.local/?page_id=38">Ir ala pagina de login</a></p><br>
        </div>
        </div>
    <?php
    }
// FIN REDIRECCION A LOGIN SI NO ESTA LOGEADO =======================================================
?>

<div id="vault">
<div class="card-body-admin"><br>
   <div class="card-content-admin">
	<h1>Gastos introducidos por usuario</h1>
    <?php
        $user=$current_user->ID;

        $expenses=ExpensesDB::selectExpensesUser($user);

        echo "<dl>\n";
        echo "<table class='fondoTabla' cellspacing='5' cellpadding='5' border='1'>";
        echo " <tr>";
        echo "  <th>ID Usuario</th>";
        echo "  <th>Descripción</th>";
        echo "  <th>Importe</th>";
        echo "  <th>Divisa</th>";
        echo "  <th>Fecha</th>";
        echo "  <th>Proyecto</th>";
        echo "  <th>Pais</th>";
        echo "  <th>Ticket</th>";
        echo " </tr>";

        foreach($expenses as $spent){
            
            echo "<tr>";
            echo "<td>".$spent->getWp_users_ID()."</td>";
            echo "<td>".$spent->getExpenses_description()."</td>";
            echo "<td>".$spent->getExpenses_import()."</td>";
            echo "<td>".$spent->getExpenses_cointype()."</td>";
            echo "<td>".$spent->getExpenses_date()."</td>";
            echo "<td>".$spent->getExpenses_project()."</td>";
            echo "<td>".$spent->getExpenses_country()."</td>";
            echo "<td>".$spent->getExpenses_ticket_ref()."</td>";
            echo "</tr>";
    
        }
    
        echo "</table>\n";
         echo "<a href='https://layer8.local/?page_id=24'> SALIR </a>"; ?> 
		</div>
	</div>
</div>
	
<?php
    if( $sidebar_layout == 'right-sidebar' )
    get_sidebar();
    get_footer();
?>