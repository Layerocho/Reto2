<?php
	
    class ExpensesDB
    {
        //ESTA FUNCION MUESTRA TODOS LOS GASTOS REGISTRADOS POR USUARIOS
        public static function selectExpenses(){
			try{
				//$db = new PDO("mysql:host=localhost;dbname=wordpress","root","programacion");
				$db = new PDO("mysql:host=192.168.1.242:3306;dbname=wordpress","JonNieves","Drakaris2");//ACTULIZAR LOS DATOS DE LA CONEXION
				$registros=$db->query("select * from wp_expenses");
				$expenses=array();
				
				while($registro = $registros->fetch()){
					
					$spent = new Spent();
					$spent->setExpenses_id($registro['expenses_id']);
					$spent->setExpenses_date($registro['expenses_date']);
					$spent->setExpenses_description($registro['expenses_description']);
					$spent->setExpenses_import($registro['expenses_import'] );
					$spent->setExpenses_cointype($registro['expenses_cointype']);
					$spent->setExpenses_project($registro['expenses_project']);
					$spent->setExpenses_country($registro['expenses_country']);
                    $spent->setExpenses_ticket_ref($registro['expenses_ticket_ref']);
                    $spent->setWp_users_id($registro['wp_users_ID']);	

                    $expenses[] = $spent;//EL ARRAY 'EXPENSES' ESTA FORMADO de MUCHOS 'SPENT'
				}
				return $expenses;
			}catch (Exception $e){
				echo "Excepcion: " . $e->getMessage();
				return null;
			}
		}

		//ESTA FUNCION FILTRA EL GASTO POR 'ID_gasto'
		public static function selectSpent($ID_Spent){
			try{
				
				//$db = new PDO("mysql:host=localhost;dbname=wordpress","root","programacion");
				$db = new PDO("mysql:host=192.168.1.242:3306;dbname=wordpress","JonNieves","Drakaris2");//ACTULIZAR LOS DATOS DE LA CONEXION
				$registros=$db->query("select * from wp_expenses where expenses_id=" . $ID_Spent);
				$spent=null;
				while($registro = $registros->fetch()){
					
					$spent = new Spent();
					$spent->setExpenses_id($registro['expenses_id']);
					$spent->setExpenses_date($registro['expenses_date']);
					$spent->setExpenses_description($registro['expenses_description']);
					$spent->setExpenses_import($registro['expenses_import'] );
					$spent->setExpenses_cointype($registro['expenses_cointype']);
					$spent->setExpenses_project($registro['expenses_project']);
					$spent->setExpenses_country($registro['expenses_country']);
                    $spent->setExpenses_ticket_ref($registro['expenses_ticket_ref']);
                    $spent->setWp_users_id($registro['wp_users_ID']);					
				}
				return $spent;
			}catch(Exception $e){
				echo "Excepcion: " . $e->getMessage();
				return null;
			}
		}




        //ESTA FUNCION MUESTRA EL ARRAY DE LOS GASTOS QUE HA REGISTRADO 1 USUARIO

        public static function selectExpensesUser($user){
			try{
				//$db = new PDO("mysql:host=localhost;dbname=wordpress","root","programacion");
				$db = new PDO("mysql:host=192.168.1.242:3306;dbname=wordpress","JonNieves","Drakaris2");//ACTULIZAR LOS DATOS DE LA CONEXION
				$registros=$db->query("select * from wp_expenses where wp_users_ID=" . $user);
				$expenses=array();

				while($registro = $registros->fetch()){
					
					$spent = new Spent();
					$spent->setExpenses_id($registro['expenses_id']);
					$spent->setExpenses_date($registro['expenses_date']);
					$spent->setExpenses_description($registro['expenses_description']);
					$spent->setExpenses_import($registro['expenses_import'] );
					$spent->setExpenses_cointype($registro['expenses_cointype']);
					$spent->setExpenses_project($registro['expenses_project']);
					$spent->setExpenses_country($registro['expenses_country']);
                    $spent->setExpenses_ticket_ref($registro['expenses_ticket_ref']);
                    $spent->setWp_users_ID($registro['wp_users_ID']);	

                    $expenses[] = $spent;//EL ARRAY 'EXPENSES' ESTA FORMADO de MUCHOS 'SPENT'			
				}
				return $expenses;
			}catch(Exception $e){
				echo "Excepcion: " . $e->getMessage();
				return null;
			}
		}


        //ESTA FUNCION INSERTA UN REGISTRO EN LA BASE DE DATOS 'EXPENSES'
        public static function insertSpent($spent){
			
            //$db = new PDO("mysql:host=localhost;dbname=wordpress","root","programacion");
			$db = new PDO("mysql:host=192.168.1.242:3306;dbname=wordpress","JonNieves","Drakaris2");//ACTULIZAR LOS DATOS DE LA CONEXION
            $resultado=$db->exec("insert into wp_expenses (expenses_date,expenses_description,expenses_import,expenses_cointype,expenses_project,expenses_country,expenses_ticket_ref,wp_users_ID) values ('" .$spent->getExpenses_date(). "','" .$spent->getExpenses_description(). "','" .$spent->getExpenses_import(). "','" .$spent->getExpenses_cointype(). "','" .$spent->getExpenses_project(). "','".$spent->getExpenses_country()."','".$spent->getExpenses_ticket_ref()."','".$spent->getWp_users_ID()."')");
            
            
            return $resultado;

        
    	}


		//ESTA FUNCION ELIMINA UN REGISTRO EN LA TABLA 'EXPENSES'
		public static function deleteSpent($ID_spent){
			
			//$db = new PDO("mysql:host=localhost;dbname=wordpress","root","programacion");
			$db = new PDO("mysql:host=192.168.1.242:3306;dbname=wordpress","JonNieves","Drakaris2");//ACTULIZAR LOS DATOS DE LA CONEXION
			$resultado=$db->exec("delete from wp_expenses where expenses_id=". $ID_spent);
			

			//echo "delete from noticias where Id=$id";
			return $resultado;
		}


		//ESTA FUNCION ACTUALIZA UN REGISTRO EN LA TABLA 'EXPENSES'
		public static function updateSpent($updated_spent){
			
			//$db = new PDO("mysql:host=localhost;dbname=wordpress","root","programacion");
			
			$db = new PDO("mysql:host=192.168.1.242:3306;dbname=wordpress","JonNieves","Drakaris2");//ACTULIZAR LOS DATOS DE LA CONEXION
			$resultado=$db->exec("update wp_expenses set expenses_date='" .$updated_spent->getExpenses_date(). "', expenses_description='" .$updated_spent->getExpenses_description()."', expenses_import='" .$updated_spent->getExpenses_import()."', expenses_cointype='" .$updated_spent->getExpenses_cointype()."', expenses_project='" .$updated_spent->getExpenses_project()."', expenses_country='" .$updated_spent->getExpenses_country()."', expenses_ticket_ref='" .$updated_spent->getExpenses_ticket_ref()."' where expenses_id=".$updated_spent->getExpenses_id());
			

			
			return $resultado;
		}


    }

?>